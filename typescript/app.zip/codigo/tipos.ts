(function(){  
    
    let mensaje: string = "Hola";
    let numero: number = 123;
    let booleano: boolean = true; 
    let fecha: Date = new Date();
  
    let cualquiercosa: string | number | boolean; 
  
    cualquiercosa = 123;
    cualquiercosa = "Clase";
    cualquiercosa = true;
  
    let persona = {
        genero: "X",
        nombre: "Clase",
        edad: 33
    }    
  
      console.log(persona);
  
      persona =  {
          genero:"A",
          edad: 50,
          nombre: "Clase 2022",
      }
  
  })();
  