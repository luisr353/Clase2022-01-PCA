( ()=> {  

    const enviarMision = ( avenger: { alias: string } )=>{
        console.log(`Enviando a ${avenger.alias} a la mision`);
    }

    const regresarDeLaMision = ( avenger: { alias: string } )=>{
        console.log(`Regreso ${avenger.alias} de la mision`);
    }
    
    
    const heroe = {
        alias: 'Iroman',
        poder:  'Rayo'
    }

    enviarMision(heroe);
    regresarDeLaMision(heroe);



})();
