"use strict";
(function () {
    var enviarMision = function (avenger) {
        console.log("Enviando a ".concat(avenger.alias, " a la mision"));
    };
    var regresarDeLaMision = function (avenger) {
        console.log("Regreso ".concat(avenger.alias, " de la mision"));
    };
    var heroe = {
        alias: 'Iroman',
        poder: 'Rayo'
    };
    enviarMision(heroe);
    regresarDeLaMision(heroe);
})();
